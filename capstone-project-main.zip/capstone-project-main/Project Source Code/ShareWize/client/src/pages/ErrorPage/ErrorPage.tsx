export default function ErrorPage() {
  return (
    <>
      <div className="container-fluid">
        <div className="row intro">
          <div className="col">
            <h1 style={{color:'red'}}>
                Page Not Found 
            </h1>
          </div>
        </div>
      </div>
    </>
  )
}
