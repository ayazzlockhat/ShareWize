We kept the calls notes and data in google drive but realized later that we need to upload them here, thus the late commits
